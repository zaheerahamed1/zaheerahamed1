import json
import pandas as pd

# Example FHIR claim JSON
with open('../data/fhir_sample_claims.json') as f:
    fhir_data = json.load(f)

# Convert to DataFrame
df = pd.json_normalize(fhir_data['entry'])

# Simple processing
df['anomaly_flag'] = df['resource.resourceType'].apply(lambda x: 1 if x != 'Claim' else 0)

# Save processed data
df.to_csv('../data/processed_claims.csv', index=False)
print('FHIR claims processed and saved.')
