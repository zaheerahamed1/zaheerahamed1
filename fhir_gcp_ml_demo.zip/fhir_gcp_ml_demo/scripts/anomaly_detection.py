import pandas as pd
from sklearn.ensemble import IsolationForest

# Load processed data
df = pd.read_csv('../data/processed_claims.csv')

# Simple feature engineering: dummy example
X = df[['anomaly_flag']]

# Train IsolationForest
model = IsolationForest(contamination=0.1, random_state=42)
df['anomaly_score'] = model.fit_predict(X)

# Save model output
df.to_csv('../data/anomaly_results.csv', index=False)
print('Anomaly detection completed. Results saved.')
