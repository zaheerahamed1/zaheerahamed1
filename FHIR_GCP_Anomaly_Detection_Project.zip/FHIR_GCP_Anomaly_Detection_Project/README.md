﻿This is the FHIR_GCP_Anomaly_Detection_Project.
# FHIR + GCP ML - Anomaly Detection in Healthcare Claims

This project demonstrates how to detect anomalies in healthcare claims data using HL7 FHIR data standards combined with Google Cloud Platform's machine learning services.

**Key Features:**
- FHIR-based healthcare claims ingestion
- Data preprocessing using BigQuery & Cloud Dataflow
- Anomaly detection using GCP Vertex AI and AutoML
- Visualization of detected anomalies in Looker Studio

**Tech Stack:** FHIR, BigQuery, Vertex AI, Python, GCP

