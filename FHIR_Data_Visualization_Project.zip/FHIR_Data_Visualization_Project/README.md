﻿This is the FHIR_Data_Visualization_Project.
# FHIR Data Visualization

This project visualizes FHIR-based healthcare data using interactive dashboards.

**Highlights:**
- Parsing and loading FHIR data into BigQuery
- Creating advanced visualizations in Looker Studio & Power BI
- Patient journey visualization
- Interactive anomaly drill-downs

**Tech Stack:** FHIR, BigQuery, Looker Studio, Power BI, Python
