import json
import pandas as pd

def load_fhir_claims(filepath):
    with open(filepath) as f:
        bundle = json.load(f)
    claims = []
    for entry in bundle.get('entry', []):
        resource = entry.get('resource', {})
        if resource.get('resourceType') == 'Claim':
            claim_id = resource.get('id')
            patient_ref = resource.get('patient', {}).get('reference')
            provider_ref = resource.get('provider', {}).get('reference')
            created_date = resource.get('created')
            total_value = resource.get('total', {}).get('value')
            items = resource.get('item', [])
            if items:
                item = items[0]
                cpt_code = item.get('productOrService', {}).get('coding', [{}])[0].get('code')
                quantity = item.get('quantity', {}).get('value')
                unit_price = item.get('unitPrice', {}).get('value')
            else:
                cpt_code, quantity, unit_price = None, None, None
            claims.append({
                'claim_id': claim_id,
                'patient_ref': patient_ref,
                'provider_ref': provider_ref,
                'created_date': created_date,
                'total_value': total_value,
                'cpt_code': cpt_code,
                'quantity': quantity,
                'unit_price': unit_price
            })
    df = pd.DataFrame(claims)
    return df

def preprocess_claims(df):
    df['quantity'] = pd.to_numeric(df['quantity'], errors='coerce').fillna(0)
    df['unit_price'] = pd.to_numeric(df['unit_price'], errors='coerce').fillna(0)
    df['total_value'] = pd.to_numeric(df['total_value'], errors='coerce').fillna(0)
    return df

if __name__ == "__main__":
    df = load_fhir_claims('../data/fhir_sample_claims.json')
    df = preprocess_claims(df)
    print(df.head())