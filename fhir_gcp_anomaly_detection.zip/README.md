# FHIR + GCP ML Anomaly Detection Mini-Project

## Overview
This mini-project demonstrates loading HL7 FHIR claim data, preprocessing, and performing anomaly detection on claim amounts using Isolation Forest.

## Project Structure
- `data/fhir_sample_claims.json`: Sample claims data in HL7 FHIR format.
- `scripts/anomaly_detection.py`: Python functions to load and preprocess claims data.
- `notebooks/anomaly_detection_notebook.ipynb`: Jupyter notebook for exploratory data analysis and anomaly detection.
- `requirements.txt`: Python dependencies.

## How to run
1. Clone the repo and navigate into the folder.
2. Install dependencies: `pip install -r requirements.txt`
3. Open the notebook and run cells step-by-step to explore and detect anomalies.

## Technologies
- Python 3.x
- pandas, matplotlib, scikit-learn
- HL7 FHIR standard data