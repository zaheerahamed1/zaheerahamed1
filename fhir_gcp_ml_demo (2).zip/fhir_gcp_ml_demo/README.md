# FHIR + GCP ML + GenAI in Healthcare � Claim Anomaly Detection Demo

## Overview
This is a demo project integrating HL7 FHIR data with Google Cloud ML services, focused on detecting anomalies in healthcare claims data.

## Project Structure
- data/ � Sample FHIR JSON claim data
- scripts/ � Python scripts for loading, processing, modeling
- notebooks/ � Jupyter notebooks for visualization & experiments
- models/ � Saved models (optional)

## How to Run
1. Prepare your GCP project (Vertex AI, BigQuery, Storage)
2. Run process_fhir_claims.py to process data
3. Run nomaly_detection.py to train and test model
4. Use 
otebooks/ for EDA and visualization

## Notes
- This is an educational project. Replace sample data with real (de-identified) FHIR data in production use cases.
