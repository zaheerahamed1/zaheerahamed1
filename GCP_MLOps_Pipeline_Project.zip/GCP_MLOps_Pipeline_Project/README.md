﻿This is the GCP_MLOps_Pipeline_Project.
# GCP MLOps Pipeline for Healthcare ML Models

A complete MLOps pipeline built on Google Cloud for deploying and managing healthcare machine learning models.

**Components:**
- CI/CD pipelines using Cloud Build
- Model training and serving with Vertex AI
- Feature store integration
- Automated model retraining and monitoring
- Model registry and explainability

**Tech Stack:** GCP Vertex AI, Cloud Build, Cloud Functions, MLflow, Python
