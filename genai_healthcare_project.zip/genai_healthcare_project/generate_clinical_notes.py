
import pandas as pd

# Load sample data
df = pd.read_csv("sample_input_data.csv")

# Simulate GenAI note generation (for demo purpose only)
notes = []
for index, row in df.iterrows():
    note = f"""Patient ID: {row['patient_id']}
Visit Date: {row['visit_date']}
Diagnosis: {row['diagnosis']}
Procedure Performed: {row['procedure']}
Prescribed Medications: {row['medications']}

Clinical Note:
Patient was seen on {row['visit_date']} for {row['diagnosis']}. The following procedure was performed: {row['procedure']}. The patient was advised to take {row['medications']}.
""".strip()
    notes.append(note)

# Save notes to file
with open("sample_output_notes.txt", "w") as f:
    for note in notes:
        f.write(note + "\n\n---\n\n")

print("Sample clinical notes generated successfully.")
