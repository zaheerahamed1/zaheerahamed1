﻿This is the GenAI_in_Healthcare_Project.
# Generative AI in Healthcare

This project explores innovative applications of Generative AI in the healthcare domain.

**Use Cases:**
- Medical text summarization from EMRs
- Generation of synthetic medical records for research
- AI-driven patient education content
- Prompt engineering with LLMs (Gemini / GPT-4 / Claude)

**Tech Stack:** LangChain, OpenAI API, Google Vertex AI, Python, Streamlit
