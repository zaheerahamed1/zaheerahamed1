﻿This is the LLM_Healthcare_Chatbot_Project.
# LLM-based Healthcare Chatbot

An intelligent chatbot designed to answer patient queries using medical knowledge and EMR/FHIR data.

**Features:**
- FHIR document retrieval for RAG (Retrieval-Augmented Generation)
- Conversation flow design with LangChain agents
- Integration with Vertex AI / OpenAI GPT-4
- Deployment on Azure or GCP Cloud Run

**Tech Stack:** LangChain, FHIR, GCP, Azure, Python, Streamlit
